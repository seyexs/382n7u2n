Ext.define('Esmk.model.FunctionRegistration', {
extend: 'Ext.data.Model',
fields: [
        {name: 'name', type: 'string'}
    ]
});