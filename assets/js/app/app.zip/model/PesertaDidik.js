Ext.define('Esmk.model.PesertaDidik', {
extend: 'Ext.data.Model',
fields: [
			{name: 'propinsi', type: 'string'},
            {name: 'kabupaten', type: 'string'},
			{name: 'sekolah_id', type: 'string'},
			{name: 'sekolah', type: 'string'},
			{name: 'peserta_didik_id', type: 'string'},
			{name: 'nisn', type: 'string'},
			{name: 'nama', type: 'string'},
			{name: 'tanggal_lahir', type: 'string'},
            {name: 'alamat_jalan', type: 'string'},
    ]
});