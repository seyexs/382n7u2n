
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tbantuanpenerimasiswaViewer = Ext.create('Esmk.view.TBantuanPenerimaSiswa._grid');
	Ext.getCmp('docs-').add(tbantuanpenerimasiswaViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TBantuanPenerimaSiswa/_grid.js"></script>
