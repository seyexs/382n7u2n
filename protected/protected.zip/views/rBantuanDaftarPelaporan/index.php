
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var rbantuandaftarpelaporanViewer = Ext.create('Esmk.view.RBantuanDaftarPelaporan._grid');
	Ext.getCmp('docs-icon-app-4.99.2-Laporan-Pertanggungjawaban').add(rbantuandaftarpelaporanViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/RBantuanDaftarPelaporan/_grid.js"></script>
