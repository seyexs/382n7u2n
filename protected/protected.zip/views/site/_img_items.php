<div class="slide">
    <a href="#" title="<?php echo $data['title']; ?>"><img src="<?php echo $data['image']; ?>" width="570" height="270" alt="Slide 1"></a>
    <div class="caption" style="bottom:0">
        <p><?php echo $data['caption']; ?></p>
    </div>
</div>