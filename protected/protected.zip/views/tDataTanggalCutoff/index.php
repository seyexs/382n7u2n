
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tdatatanggalcutoffViewer = Ext.create('Esmk.view.TDataTanggalCutoff._grid');
	Ext.getCmp('docs-icon-app-4.4.98-Tanggal-Cut-Off-Data').add(tdatatanggalcutoffViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TDataTanggalCutoff/_grid.js"></script>
