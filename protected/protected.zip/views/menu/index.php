
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var menuViewer = Ext.create('Esmk.view.Menu._grid');
	Ext.getCmp('docs-icon-favorite-99.4-Menus').add(menuViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/Menu/_grid.js"></script>
