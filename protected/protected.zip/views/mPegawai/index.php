
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var mpegawaiViewer = Ext.create('Esmk.view.MPegawai._grid');
	Ext.getCmp('docs-icon-app-2.1-Pegawai').add(mpegawaiViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/MPegawai/_grid.js"></script>
