
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tbantuanpenerimaanpengembalianViewer = Ext.create('Esmk.view.TBantuanPenerimaanPengembalian._grid');
	Ext.getCmp('docs-').add(tbantuanpenerimaanpengembalianViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TBantuanPenerimaanPengembalian/_grid.js"></script>
