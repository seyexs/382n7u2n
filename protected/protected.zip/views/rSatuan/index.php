
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var rsatuanViewer = Ext.create('Esmk.view.RSatuan._grid');
	Ext.getCmp('docs-icon-app-4.99.4-Satuan').add(rsatuanViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/RSatuan/_grid.js"></script>
