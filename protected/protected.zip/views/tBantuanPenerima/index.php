
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tbantuanpenerimaViewer = Ext.create('Esmk.view.TBantuanPenerima.index');
	Ext.getCmp('docs-icon-app-4.3.2-Penentuan-Calon-Penerima').add(tbantuanpenerimaViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TBantuanPenerima/index.js"></script>
