
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tbantuantimpengelolaViewer = Ext.create('Esmk.view.TBantuanTimPengelola._grid');
	Ext.getCmp('docs-icon-app-4.1.3-Tim-Pengelola-Bantuan').add(tbantuantimpengelolaViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TBantuanTimPengelola/_grid.js"></script>
