
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var GroupsViewer = Ext.create('Esmk.view.Groups._grid');
	Ext.getCmp('docs-icon-group-99.3-Groups').add(GroupsViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/Groups/_grid.js"></script>


