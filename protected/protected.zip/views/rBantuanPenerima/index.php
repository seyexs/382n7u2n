
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var rbantuanpenerimaViewer = Ext.create('Esmk.view.RBantuanPenerima._grid');
	Ext.getCmp('docs-icon-app-4.99.3-Jenis-Penerima').add(rbantuanpenerimaViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/RBantuanPenerima/_grid.js"></script>
