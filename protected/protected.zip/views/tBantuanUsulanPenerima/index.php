
<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var tbantuanusulanpenerimaViewer = Ext.create('Esmk.view.TBantuanUsulanPenerima._grid');
	Ext.getCmp('docs-icon-app-4.3.1-Usulan-Penerima').add(tbantuanusulanpenerimaViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/TBantuanUsulanPenerima/_grid.js"></script>
