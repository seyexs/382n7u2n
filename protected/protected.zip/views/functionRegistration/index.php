<script type="text/javascript">
    var BASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
	var FunctionRegistrationViewer = Ext.create('Esmk.view.FunctionRegistration._grid');
	Ext.getCmp('docs-icon-function-99.2-Function-Registration').add(FunctionRegistrationViewer);
</script>
<script type="text/javascript" src="<?php echo Yii::app()->request->baseUrl; ?>/assets/js/app/view/FunctionRegistration/_grid.js"></script>

