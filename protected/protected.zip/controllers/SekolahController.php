<?php
class SekolahController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column1', meaning
	 * using one-column layout. See 'protected/views/layouts/column1.php'.
	 */
	public $dapodikmen;
        
    public function init() {
		$this->dapodikmen=Yii::app()->params['dapodikmenDb'];
        parent::init();
    }
	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
            'rights',
		);
	}

	public function allowedActions() 
	{ 
        return 'GetBiodata,read,GetDetailInfoSekolah'; 
    }
	public function actionGetBiodata(){
		$user=User::model()->findByPk(Yii::app()->user->id);
		if($user->kode_kepemilikan=='SP'){
			$model=Yii::app()->db->createCommand('
					select * from '.$this->dapodikmen.'.dbo.sekolah where sekolah_id=\''.$user->pemilik_id.'\'
			')->queryAll();
            echo CJSON::encode(array(
                "success" => true,
                "total" => 1,
                "data" => $model
            ));
		}
	}
	public function actionGetDetailInfoSekolah(){
		$sid=$_POST['sid'];
		$model =Yii::app()->db->createCommand('
				select  s.*, prop.nama as propinsi,kab.nama as kabupaten from '.$this->dapodikmen.'.dbo.sekolah s 
				inner join '.$this->dapodikmen.'.ref.mst_wilayah kab on left(s.kode_wilayah,4)+\'00\'=kab.kode_wilayah
				inner join '.$this->dapodikmen.'.ref.mst_wilayah prop on left(s.kode_wilayah,2)+\'0000\'=prop.kode_wilayah
				where CONVERT(NVARCHAR(32),HashBytes(\'MD5\',CONVERT(NVARCHAR(36),s.sekolah_id)),2)=\''.$sid.'\'
			')->queryAll();
		echo CJSON::encode(array(
			'success'=>true,
			'data'=>$model
		));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		
		$this->render('index');
	}
	/**
        * Read all table content
    */
        
    public function actionRead(){
            $this->layout = false;

            $start = (int) $_GET['start'];
            $limit = (int) $_GET['limit'];
			$q=(isset($_GET['q']))?$_GET['q']:'';
			$userid=Yii::app()->user->id;
			$cek_user=TUserAccessData::model()->findAll(array(
				'condition'=>'deleted=0 and userid=:uid',
				'params'=>array(':uid'=>$userid)
			));
			$filter_data='';
			if(isset($cek_user[0]->id)){
				$filter_data=" and s.kode_wilayah like '".$cek_user[0]->wilayah."%'";
			}
            $data=Yii::app()->db->createCommand('
				select s.*, prop.nama as propinsi,kab.nama as kabupaten from '.$this->dapodikmen.'.dbo.sekolah s 
				inner join '.$this->dapodikmen.'.ref.mst_wilayah kab on left(s.kode_wilayah,4)+\'00\'=kab.kode_wilayah
				inner join '.$this->dapodikmen.'.ref.mst_wilayah prop on left(s.kode_wilayah,2)+\'0000\'=prop.kode_wilayah
				where 1=1'.$filter_data.' and s.nama like \'%'.$q.'%\' and s.bentuk_pendidikan_id=15
			')->queryAll();
            $total = count($data);
			$limit=($limit+$start>$total)?($total-$start):$limit;
            $model =Yii::app()->db->createCommand('
				select CONVERT(NVARCHAR(32),HashBytes(\'MD5\',CONVERT(NVARCHAR(36),s.sekolah_id)),2) as sekolah_id,s.nama,
				case when s.status_sekolah=\'2\' then \'Negeri\' else \'Swasta\' end as status_sekolah,
				s.nomor_fax,s.email,s.website,
				s.alamat_jalan,s.npsn,s.nomor_telepon, prop.nama as propinsi,kab.nama as kabupaten from '.$this->dapodikmen.'.dbo.sekolah s 
				inner join '.$this->dapodikmen.'.ref.mst_wilayah kab on left(s.kode_wilayah,4)+\'00\'=kab.kode_wilayah
				inner join '.$this->dapodikmen.'.ref.mst_wilayah prop on left(s.kode_wilayah,2)+\'0000\'=prop.kode_wilayah
				where 1=1'.$filter_data.' and s.nama like \'%'.$q.'%\' and s.bentuk_pendidikan_id=15
			')->queryAll();

            
            echo CJSON::encode(array(
                "success" => true,
                "total" => $total,
                "data" => $model
            ));

            Yii::app()->end();
    }
	

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer the ID of the model to be loaded
	 */
	public function loadModel($id)
	{
		$model=MPegawai::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CModel the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='mpegawai-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
